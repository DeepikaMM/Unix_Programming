#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
void main()
{
int fd,c,u;
struct stat buf;

fd=open("fff.txt",O_CREAT|O_RDWR|O_APPEND,0664);
if(fd<0)
{
perror("open: ");
exit(1);
}
fstat(fd,&buf);
printf("%o\n",buf.st_mode);
printf("%o\n",buf.st_mode&~S_IRGRP);


c = (buf.st_mode&~S_IRGRP) | (S_ISUID) | (buf.st_mode&S_IRWXO)| (buf.st_mode&S_IRWXU) ;
fchmod(fd,c);

}
