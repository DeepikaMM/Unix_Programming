#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

void main(){
	int c,fd;
	struct stat buf;
	creat("per.txt",0666);
	fd = open("per.txt",O_RDONLY);
	if(fd<0){
		perror("error");
		exit(1);
	}
	if(access("per.txt",F_OK)==0){
		printf("this is a file\n");
	}
	if(access("per.txt",R_OK)==0){
		printf("Read permission\n");
	}
	if(access("per.txt",W_OK)==0){
		printf("write permission\n");
	}
	if(access("per.txt",X_OK)==0){
		printf("execute permission\n");
	}
	

}
