#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>

void main()
{
	int fd,c;
	struct stat buf;
	fd=open("d.txt",O_RDONLY|O_CREAT,0666);
	//creat("dd.txt",0444);
	fstat(fd,&buf);
	printf("%o\n",buf.st_mode);
	c=(buf.st_mode&~S_IRWXU)&(buf.st_mode&~S_IRWXG)&(buf.st_mode&~S_IRWXO);
	
	printf("%o\n",c);
        chmod("d.txt",c);
}
	
