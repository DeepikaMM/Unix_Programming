#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
void main()
{
	int fd,c;
	struct stat buf;
	fd=open("d.txt",O_RDONLY,0666);
	stat(fd,&buf);
	printf("a-time:%d\n",ctime(&buf.st_atime));
	buf.st_atime=654522999;
;
	printf("a-time:%d\n",ctime(&buf.st_atime));
}
