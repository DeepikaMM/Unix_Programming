#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
void main()
{
int fd,c,u;
struct stat buf;

fd=open("q.txt",O_CREAT|O_RDWR|O_APPEND,0666);
if(fd<0)
{
perror("open: ");
exit(1);
}
fstat(fd,&buf);
printf("Before : %o\n",buf.st_mode);
c = (buf.st_mode & ~S_IRGRP & ~S_IWGRP  & ~S_IXGRP & ~S_IRUSR & ~S_IWUSR & ~S_IXUSR );
fchmod(fd,c);


}
