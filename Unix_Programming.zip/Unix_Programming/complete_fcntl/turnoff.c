#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>

void main(int argc,char* argv[])
{
	int fd,c;
	struct stat buf;
	//fd=open("d.txt",O_RDONLY|O_CREAT,0666);
	//creat("dd.txt",0444);
	fstat(argv[1],&buf);
	printf("%o\n",buf.st_mode);
	c=(buf.st_mode&S_IRWXO)|(buf.st_mode&~S_IRGRP)|(buf.st_mode&S_IRWXO)|S_ISVTX;
	
	printf("%o\n",c);
	char i=argv[1];
	
        chmod(argv[1],c);
	
