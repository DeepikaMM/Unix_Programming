#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>

main()
{
	int fd,n;
	struct stat buf;
	fd = open("kk.txt", O_RDONLY | O_CREAT ,0666);
	if(fd<0)
	{
		perror("error");
	}
	//write(fd,"hello\n",6);
	creat("kk.txt",0444);
	fstat(fd,&buf);
	printf("%o\n",buf.st_mode);
	n = (buf.st_mode & ~S_IRWXU) & (buf.st_mode & ~S_IRWXG) & (buf.st_mode & ~S_IRWXO);
	printf("%o\n",n);
	chmod("kk.txt",n);
}
