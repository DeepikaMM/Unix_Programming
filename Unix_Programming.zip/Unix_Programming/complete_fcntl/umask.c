#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>


void main()
{
	umask(0);
	creat("tmp.txt",0666);
	umask(027);
	creat("temp1.txt",0666);
	
}
	
