
// program for user id bit // fd's are inherited after exec
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>	
main()
{
int fd,fd1,fd2;
struct stat buf;
int status;
pid_t pid;
fd=open("bb.txt",O_RDWR|O_CREAT,0664);
//fd1=fcntl();

// open a file
// get the fd

if(fd<0)
{
perror("open");
exit(1);
}
//setuid(1002);

if (fcntl(fd,F_SETFD,FD_CLOEXEC) == -1)
{
perror("fcntl");
exit(1);
}
pid=fork();
if(pid<0)
{
perror("fork");
exit(1);
}
else if(pid==0)
{
execl("./deep","deep",(char*)0);
// execute a new program that writes to a file refered by fd
printf("this statement is never printed\n");
}
else
{
waitpid(pid,&status,0);
write(fd,"i am parent\n",strlen("i am parent\n"));
}
}

