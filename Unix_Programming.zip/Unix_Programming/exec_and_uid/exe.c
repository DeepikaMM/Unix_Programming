#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>	
main()
{
	write(3,"hello world",11);
}
