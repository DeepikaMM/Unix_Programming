// program for user id bit
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
main()
{
int fd,fd1,fd2;
struct stat buf;
//open a file here
fd=open("aa.txt",O_RDWR|O_APPEND,0664);
if(fd<0)
{
perror("open");
exit(1);
}
// set the user id using setuid(uid)
setuid(1002);
fstat(fd,&buf);
printf("uid=%d gid=%d",buf.st_uid,buf.st_gid);
//print the usre id, euid
	
// write to the file any message

}
