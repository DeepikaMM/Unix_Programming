//write a pgm to print a LOG name value(env variable)
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
int main()
{
	//char *getenv(LOGNAME);
	char *x;
	x=getenv("LOGNAME");
	printf("%s\n",x);
	setenv("LOGNAME","deepika",1);// only for this process not the env of the kernal
	x=getenv("LOGNAME");
	printf("%s\n",x);
}
