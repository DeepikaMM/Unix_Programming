#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
int main()
{
	int pid;
	pid=fork();
	if(pid==0)
	{
		printf("child");
		exit(1);
	}
	else if(pid>0)
	{
		sleep(10);
		printf("hello");
	}

}
