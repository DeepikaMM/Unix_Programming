#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdlib.h>
int fd,fd1;
char buf[6];
void child();
void parent();
void main()
{
	
	pid_t pr1;
	fd=open("h.txt",O_RDWR|O_CREAT,0666);
	fd=open("m.txt",O_RDWR|O_CREAT,0666);
	fd1=
	pr1=fork();
	if(pr1==-1)
	printf("error");
	if(pr1==0)
	child();
	else
	parent();
	
	
}
void child()
{	
	write(fd,"child",5);
	lseek(fd1,0,0);
	read(fd1,buf,5);
	printf("%s",buf);
}
void parent()
{
	write(fd1,"parent",6);
	
	lseek(fd,0,0);
	read(fd,buf,5);
	printf("%s",buf);
}

