#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

main()
{
	printf("IN MAIN-1...\n");
	alarm(4);
	execl("./m2","m2",(char*)0);
}
