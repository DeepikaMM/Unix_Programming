#include<signal.h>
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
static void ha(int signo,int errno,siginfo_t *s,void *context)
{
   printf("\nSIGNAL NO =%d\nERROR VALUE =%d\n PID=%d\n UID =%d\n",signo,errno,s->si_pid,s->si_uid);
	fflush(stdout);
	exit(0);
}
void main()
{
   printf("%d",getpid());
   struct sigaction act;
	act.sa_sigaction=ha;
	sigemptyset(&act.sa_mask);
	act.sa_flags=SA_SIGINFO;
	
   sigaction(SIGTSTP,&act,NULL);
	sigaction(SIGINT,&act,NULL);
	for(;;){}
	
	
}

