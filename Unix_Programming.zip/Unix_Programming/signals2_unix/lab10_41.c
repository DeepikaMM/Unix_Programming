#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static void ha(int signo)
{
	if(signo==SIGALRM)
		printf("\nSIGALRM signal handler\n");
	exit(0);
}

main()
{
	signal(SIGALRM,ha);
	while(1)
		pause();
}
