#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<sys/stat.h>
main()
{
    pid_t pid,w;
    int i;

    pid =fork();
    if(pid==-1)
    {
        exit(1);
    }

    else if(pid==0)
    {
        printf("In child :\n");
        for(i=0;i<=10;i++)
        {
            printf("%d\t",i);
            pause();
            kill(getppid(),SIGUSR2);
        }
    }
    else if(pid>0)
    {
        printf("In parent :\n");
        for(i=1;i<=5;i++)
        {
            printf("%d\t",i);

            kill(getppid(),SIGUSR1);
            pause();
        }
    }
}
