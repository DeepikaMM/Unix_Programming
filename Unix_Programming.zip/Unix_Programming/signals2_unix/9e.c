#include<signal.h>
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
static void ha(int);
void main()
{
   struct sigaction act;
	act.sa_handler=ha;
	sigemptyset(&act.sa_mask);
	act.sa_flags=0;
   sigaction(SIGINT,&act,NULL);
	for(;;){}
	
	
}
static void ha(int signo)
{
   printf("Caught\n");
	fflush(stdout);
	exit(0);
}
