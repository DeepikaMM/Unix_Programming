#include<stdio.h>
#include<fcntl.h>
#include<signal.h>
#include<stdlib.h>
static void ha(int signo);
int main()
{
	int i, count=0;
	sigset_t mask1, pendmask;
	signal(SIGINT, ha);
	signal(SIGTSTP, ha);
	sigemptyset(&mask1);
	sigaddset(&mask1, SIGINT);
	sigaddset(&mask1, SIGTSTP);
	sigaddset(&mask1, SIGALRM);
	if(sigprocmask(SIG_BLOCK,&mask1,NULL)<0)
	{
		perror("sigprocmask");
		exit(0);
	}
	//sleep(4);
	
	if(sigprocmask(SIG_SETMASK,&mask1,NULL)<0)
	{
		perror("sigprocmask");
		exit(0);
	}
	if(sigpending(&pendmask)){
		perror("error occured");
		exit(0);
	}
	printf("starting count\n");
	for(i=1;i<NSIG;i++)
	{
		if(sigismember(&mask1,i))
		{
			count++;
		}
	}
	//sleep(4);
	printf("count - %d",count);
	exit(0);
	
}

static void ha(int signo)
{
	printf("signal is caught \n");
	//exit(0);
}

