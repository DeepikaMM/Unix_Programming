#include <signal.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
int i =0,j=0;
static void ha(int signo)
{
	fflush(stdout);
}
void main()
{
	int pid;
	signal(SIGUSR1,ha);
	signal(SIGUSR2,ha);
	pid = fork();
	if(pid==0)
	
	{
		
		for(i=97;i<123;i++)
		{
		
			printf("%c",i );
			fflush(stdout);
			
			
			kill(getppid(),SIGUSR1);
	pause();
			
		}
	}
	else
	{
		for(i=65;i<91;i++)
		{
		
			pause();
			printf("%c",i );
			fflush(stdout);
			
			kill(pid,SIGUSR2);
			
		}
	}
}

