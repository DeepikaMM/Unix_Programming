#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

static void ha(int signo);
main()
{
	if(signal(SIGINT,ha)==SIG_ERR)
		printf("signal error for sigint\n");
	if(signal(SIGUSR1,ha)==SIG_ERR)
		printf("signal error for sigusr1\n");
	printf("%d\n",getpid());
	while(1)
	pause;
}

static void ha(int signo)
{
	if(signo==SIGINT)
		printf("\nSIGINT signal handler\n");
	if(signo==SIGUSR1)
		printf("\nSIGUR1 signal handler\n");
}
