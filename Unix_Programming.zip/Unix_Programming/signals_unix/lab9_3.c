#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

static void ha(int signo);
main()
{
	if(signal(SIGINT,ha)==SIG_ERR)
		printf("signal error for sigint\n");
	printf("%d\n",getpid());
	while(1);
}

static void ha(int signo)
{
	if(signo==SIGINT)
	printf("\nSIGINT signal handler\n");
	signal(SIGINT,SIG_DFL);
}
