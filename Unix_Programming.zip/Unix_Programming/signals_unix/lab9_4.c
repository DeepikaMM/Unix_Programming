#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

static void rec(int signo)
{
	if(signo==SIGINT)
	{
		printf("SIGINT\n");
	}
	if(signo==SIGQUIT)
	{
		printf("SIGQUIT\n");
	}
	if(signo==SIGTSTP)
	{
		printf("SIGTSTP\n");
	}
}

int main()
{
	sigset_t mask1,mask2;
	signal(SIGINT,rec);
	signal(SIGQUIT,rec);
	signal(SIGTSTP,rec);
	
	sigemptyset(&mask1);
	sigaddset(&mask1,SIGINT);
	sigaddset(&mask1,SIGQUIT);
	sigaddset(&mask1,SIGTSTP);
	
	sigprocmask(SIG_BLOCK,&mask1,&mask2);
	sleep(4);
	sigprocmask(SIG_SETMASK,&mask2,NULL);
	exit(0);
}
