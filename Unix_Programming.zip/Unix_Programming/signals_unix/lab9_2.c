#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

static void ha(int signo);
static void def_ign(int signo);
main()
{
	if(signal(SIGINT,ha)==SIG_ERR)
		printf("signal error for sigint\n");
	if(signal(SIGKILL,ha)==SIG_ERR)
		printf("signal error for sigkill\n");
	if(signal(SIGSTOP,ha)==SIG_ERR)
		printf("signal error for sigstop\n");
	if(signal(SIGQUIT,ha)==SIG_ERR)
		printf("signal error for sigquit\n");
	if(signal(SIGTSTP,ha)==SIG_ERR)
		printf("signal error for sigtstp\n");
	printf("%d\n",getpid());
	while(1);
}

static void ha(int signo)
{
	if(signo==SIGINT)
		printf("\nSIGINT signal handler\n");
	if(signo==SIGKILL)
		printf("\nSIGKILL signal handler\n");
	if(signo==SIGSTOP)
		printf("\nSIGSTOP signal handler\n");
	if(signo==SIGQUIT)
		printf("\nSIGQUIT signal handler\n");
	if(signo==SIGTSTP)
		printf("\nSIGTSTP signal handler\n");
	exit(0);
}
