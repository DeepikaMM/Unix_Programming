#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>

main()
{
	signal(SIGINT,SIG_IGN);
	signal(SIGKILL,SIG_IGN);
	signal(SIGSTOP,SIG_IGN);
	signal(SIGQUIT,SIG_IGN);
	signal(SIGTSTP,SIG_IGN);
	printf("%d\n",getpid());
	while(1);
}

