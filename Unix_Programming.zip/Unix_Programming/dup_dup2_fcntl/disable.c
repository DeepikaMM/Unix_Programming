#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

void main()
{
	int flags =O_WRONLY;
	int val1,val,val2,fd,val3,val4;
	fd=open("g.txt",O_RDWR|O_CREAT|O_APPEND|O_TRUNC,0666);
	val2=fcntl(fd,F_GETFL,0);
	val2=val2&O_ACCMODE;
	switch(val2)
	{
		case 0:printf("read only\n");break;
		case 1:printf("write only\n");break;
		case 2:printf("read write\n");break;
	}
	if(val2&O_APPEND)
	printf("append\n");
	if(val2&O_CREAT)
	printf("creat\n");
	if(val2&O_NONBLOCK)
	printf("nonblock\n");
	if(val2&O_TRUNC)
	printf("trunc");

	val = flags;
	fcntl(fd,F_SETFL,val);
        val4=fcntl(fd,F_GETFL,0);
	val3=val4&O_ACCMODE;
	printf("%d",val3);
	switch(val3)
	{
		case 0:printf("read only\n");break;
		case 1:printf("write only\n");break;
		case 2:printf("read write\n");break;
	}
	if(val3&O_APPEND)
	printf("append\n");
	if(val3&O_CREAT)
	printf("creat\n");
	if(val3&O_NONBLOCK)
	printf("nonblock\n");
	if(val3&O_TRUNC)
	printf("trunc");
	
}
