#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

void main()
{
	int fd,fd1,fd2;char buf[10];
	fd=open("a.txt",O_RDWR|O_CREAT,0666);
	fd1=open("c.txt",O_RDWR|O_CREAT,0666);
	printf("fd1=%d",fd1);
	printf("fd=%d",fd);
	fd2=dup2(fd,fd1);
	write(fd1,"hello\n",6);
	printf("fd=%d\nfd2=%d",fd,fd2);
	close(fd2);
}
