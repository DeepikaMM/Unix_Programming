#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

void main()
{
	int fd,fd1,fd2;
	fd=open("e.txt",O_WRONLY|O_CREAT|O_APPEND,0666);
	fd1=open("d.txt",O_WRONLY|O_CREAT|O_APPEND,0666);
	close(fd1);
	fcntl(fd,F_DUPFD,fd1);
	write(fd1,"good",4);
        write(fd,"gddd",4);
	printf("fd=%d",fd);
	printf("fd1=%d",fd1);
	//printf("fd2=%d",fd2);
	
}
