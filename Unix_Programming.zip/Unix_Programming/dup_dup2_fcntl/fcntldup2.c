#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
void main()
{
int fd,fd1,fd3,fd4;
fd=open("a.txt",O_RDWR|O_CREAT,0666);
fd4=open("ab.txt",O_RDWR|O_CREAT,0666);
//fd1=dup2(fd,fd3);
close(fd4);
fcntl(fd,F_DUPFD,fd4);
write(fd,"hello world people!\n",20); 
write(fd4,"good morning!\n",13);
printf( "fd:%d,fd1:%d,fd3:%d,fd4:%d",fd,fd1,fd3,fd4);
}
