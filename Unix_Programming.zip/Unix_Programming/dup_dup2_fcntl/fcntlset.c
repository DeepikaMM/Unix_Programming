#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

void main()
{
	int flags =O_RDWR|O_TRUNC;
	int val1,val,val2,fd;
	fd=open("g.txt",O_WRONLY|O_CREAT|O_APPEND,0666);
	val=fcntl(fd,F_GETFL,0);
	val |= flags;
	fcntl(fd,F_SETFL,val);
        val2=fcntl(fd,F_GETFL,0);
	//val2=val1&O_ACCMODE;
	printf("set=%d",val);
	switch(val2)
	{
		case 0:printf("read only\n");break;
		case 1:printf("write only\n");break;
		case 2:printf("read write\n");break;
	}
	if(val2&O_APPEND)
	printf("append\n");
	if(val2&O_CREAT)
	printf("creat\n");
	if(val2&O_NONBLOCK)
	printf("nonblock\n");
	if(val2&O_TRUNC)
	printf("trunc");
	
	
}
