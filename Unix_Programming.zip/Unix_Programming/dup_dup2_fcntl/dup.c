#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

void main()
{
	int fd,fd1;char buf[10];
	fd=open("a.txt",O_RDWR|O_CREAT,0666);
	fd1=dup(fd);
	write(fd1,"hello\n",6);
	printf("fd=%d\nfd1=%d",fd,fd1);

}
