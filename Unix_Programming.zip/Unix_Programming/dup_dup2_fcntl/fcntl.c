#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

void main()
{
	int fd,val,val1;
	fd=open("b.txt",O_WRONLY|O_CREAT|O_APPEND,0666);
	val=fcntl(fd,F_GETFL,0);
	val1=val&O_ACCMODE;
	switch(val1)
	{
		case 0:printf("read only\n");break;
		case 1:printf("write only\n");break;
		case 2:printf("read write\n");break;
	}
	if(val&O_APPEND)
	printf("append\n");
	if(val&O_CREAT)
	printf("creat\n");
	if(val&O_NONBLOCK)
	printf("nonblock\n");
	if(val&O_TRUNC)
	printf("trunc");
	
	
}
