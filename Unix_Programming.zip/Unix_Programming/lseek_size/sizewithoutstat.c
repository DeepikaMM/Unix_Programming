#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>
void main(int argc,char* argv[])
{
int fd,val,val1,val2,i,fd1;
struct stat buf;
char buffer[10];
if(lstat(argv[1],&buf)&0)
{
perror("error");
exit(1);
}

fd=open("a.txt",O_CREAT|O_RDWR,0666);
fd1=open("b.txt",O_CREAT|O_RDWR,0666);

val=lseek(fd,0,2);
printf("size: %d\n ",val);

//write(fd,"hello\n",6);

lseek(fd,5,2);
write(fd,"hello\n",6);

val1=lseek(fd,0,2);
printf("after writing: %d ",val1);

for(i=0;i<val1;i++)
{
lseek(fd,i,0);
read(fd,buffer,1);
write(fd1,buffer,1);
}
printf("%c",buffer[0]);

val2=lseek(fd1,0,2);
printf("after writing: %d ",val2);

}
