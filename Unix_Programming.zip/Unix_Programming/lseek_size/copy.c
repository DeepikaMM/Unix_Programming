#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

void main()
{
	int fd,val;
	fd=open("z.txt",O_RDWR|O_CREAT|O_APPEND,0666);
	write(fd,"abcdefghijklmnopqrstuvwxyz\n",26);
	lseek(fd,10,2);
	write(fd,"abcdefghijklmnopqrstuvwxyz\n",26);
	close(fd);
}
