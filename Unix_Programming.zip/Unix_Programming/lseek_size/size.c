#include<stdio.h>
#include<fcntl.h>
#include<time.h>
#include<unistd.h>
#include<stdlib.h>
void main(int argc,char* argv[])
{
int fd;
struct stat buf;
if(lstat(argv[1],&buf)&0)
{
perror("error");
exit(1);
}

printf("size - %ld",buf.st_size);
printf(" ctime - %s",ctime(&buf.st_ctime));
printf(" atime - %s",ctime(&buf.st_atime));
}
