#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

void main()
{
	int fd,val;
	fd=open("b.txt",O_RDWR|O_CREAT|O_APPEND,0666);
	//write(fd,"abcdefghijklmnopqrstuvwxyz\n",26);
	val=lseek(fd,0,2);
	printf("%d\n",val);
}
