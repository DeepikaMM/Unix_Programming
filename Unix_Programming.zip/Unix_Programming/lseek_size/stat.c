#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/stat.h>\
#include <time.h>

int main(int argc,char* argv[])
{
	int fd;
	struct stat buf;
	if(stat (argv [1],&buf)<0)
	{
		perror("error");
		 exit(1);
	}
	if(S_ISREG(buf.st_mode))
	printf("regular\n");
	if(S_ISDIR(buf.st_mode))
	printf("directory");
	if(S_ISBLK(buf.st_mode))
	printf("block");
	if(S_ISCHR(buf.st_mode))
	printf("charctar");
	if(S_ISFIFO(buf.st_mode))
	printf("fifo");
	if(S_ISSOCK(buf.st_mode))
	printf("socket");
	if(S_ISLNK(buf.st_mode))
	printf("links");
	
	printf("i node -%d\n",buf.st_ino);
	printf("size -: %d\n",buf.st_size);
	printf("links : %d\n",buf.st_nlink);
	printf("dev: %d",buf.st_dev);
	printf("block-size: %d\n",buf.st_blksize);
	printf("number of blocks:%d\n",buf.st_blocks);
	printf("c-time:%d\n",ctime(&buf.st_ctime));
	printf("a-time:%d\n",ctime(&buf.st_atime));
	printf("m-time:%d\n",ctime(&buf.st_mtime));	
}
