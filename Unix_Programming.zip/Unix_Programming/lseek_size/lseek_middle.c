#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

main()
{
	int fd,fd1;
	char buf[20];
	fd=open("t.txt",O_RDWR|O_CREAT|O_APPEND,0666);
	write(fd,"hhhhh",5);
	lseek(fd,-2,2);
	read(fd,buf,2);
	printf(buf);
	fd1=lseek(fd,0,2);
	printf("%d",fd1);
}
