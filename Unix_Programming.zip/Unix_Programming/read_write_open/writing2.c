 //write a program to write 5lines of data to a file and 
//1. display the single line from the file.
//2. display the 2 line from the file.
//3. display the n bytes from the file.

#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main()
{
int fd;int i;
char buf[1];
int check=1;
int count=0;
fd = open("a.txt",O_RDWR|O_CREAT, 0664);
printf("%d\n",fd);
write(fd,"good morning\ngood morning\ngood morning\ngood morning\ngood morning\n",65); // 65 is number of bytes.
i=0;
while(check==1)
{

	lseek(fd,i,0);
	i=i+1;
	 // if we read without lseek we will get garbage data,bcoz it cannot go to top to read..without lseek it will try to read from 		the current position after read..
	// lseek will take the pointer to given position in 2nd argument.
	read(fd,buf,1);
	printf("%c",buf[0]);
		if(buf[0]=='\n')
		{
		check=0;
		}

}
check=1;
i=0;
while(check==1)
{

	lseek(fd,i,0);
	i=i+1;
	read(fd,buf,1);
	printf("%c",buf[0]);
		if((buf[0]=='\n') && (count!=2))
		{
		//printf("in if1");
		count++;
		}
		if(count==2)
		{
		//printf("in if2");
			check=0;
		}
}



close(fd);
}
