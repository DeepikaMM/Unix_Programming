//Write a program to write 5 lines of data to a file and display a single (first) line; display 2 lines; display n bytes
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
void main(){
    int fd,i,j,count=0;
    int found = 1;
    int n=28;
    int nolines;
    char buf[1],buf2[n];
    fd = open("three.txt",O_RDWR|O_CREAT, 0664);
    printf("Enter the number of lines\n");
    scanf("%d",&nolines);
    printf("%d\n",fd);
    for(i=0;i<5;i++){
        write(fd,"hello world people!\n",20);
    }
    
    j=0;
    while(found==1){
        lseek(fd,j,0); // to take the file pointer to the starting of the file 
        
        read(fd,buf,1);
        printf("%c",buf[0]);
        if(buf[0]=='\n'){
            break;
        }
        j++;

    }
    printf("\n");
    j=0;
    while(found==1){
        lseek(fd,j,0); // to take the file pointer to the starting of the file 
        
        read(fd,buf,1);
        printf("%c",buf[0]);
        if((buf[0]=='\n')&&(count !=nolines)){
            count++;
        }
        if(count == nolines){
            break;
        }
        j++;

    }
    printf("\n");
    lseek(fd,0,0);
    read(fd,buf2,n);
    for(i=0;i<n;i++){
        printf("%c",buf2[i]);
    }
    printf("\n");
    
    
    close(fd);
	
}
/*
Extra work:
Write a program to read n student records (name,usn,marks,mailid,dob)
Display all the records entered
Display 'i'th record entered
*/
