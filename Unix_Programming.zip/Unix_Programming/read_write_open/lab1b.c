//Write a program to write 20 bytes of data to a file and display the last 10 bytes from the file.
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
void main(){
    int fd;
    char buf[20];
    fd = open("two.txt",O_RDWR|O_CREAT, 0664);
    printf("%d\n",fd);
    write(fd,"hello world people!\n",20);
    lseek(fd,-10,2); // to take the file pointer to the starting of the file 
    read(fd,buf,10);
    printf("%s\n",buf);
    close(fd);
	
}

