//this pgmwill display 20,24 and 26 bytes od data from the opened file
#include<unistd.h>
#include<stdio.h>
#include<fcntl.h>

int main()
{
	int fd;int i;
	char buf[36];
	fd=open("bb.txt",O_RDWR|O_CREAT,0644);
	printf("%d",fd);
	write(fd,"deepikammdeepikamm10\nhai\nhai\nhai\nhai",36);
	//printf("%s",buf);
	printf("enter 1:read 1 line,enter 2:read 2 lines,enter 3:read 24 bytes");
	scanf("%d",&i);
	if(i==1)
	{
	
	lseek(fd,0,0);
	read(fd,buf,20);
	printf("%s",buf);
	}
	else if(i==2)
	{
	lseek(fd,0,0);
	read(fd,buf,24);
	printf("%s",buf);
	}
	else if(i==3)
	{
	lseek(fd,0,0);
	read(fd,buf,26);
	printf("%s",buf);
	}
	close(fd);
	return 0;
}
