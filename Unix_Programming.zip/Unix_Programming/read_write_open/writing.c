//write a program to write 20bytes of data to a file and display the last 10 bytes from the file.

#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main()
{
int fd;
char buf[20];
fd = open("aa.txt",O_RDWR|O_CREAT, 0664);
printf("%d\n",fd);
write(fd,"hellofr good morning",20); // 20 is number of bytes.
lseek(fd,-10,2); // if we read without lseek we will get garbage data,bcoz it cannot go to top to read..without lseek it will try to read from the current position after read..
// lseek will take the pointer to given position in 2nd argument.
// lseek 3rd argument is position presnt then 2nd argument as offset.
read(fd,buf,10);
printf("%s",buf);
close(fd);
}
