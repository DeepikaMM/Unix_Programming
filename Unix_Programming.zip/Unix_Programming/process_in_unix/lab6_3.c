#include<sys/wait.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
int a[]={3,2,1,4};
void child();
void parent();
int status;
void main()
{
	pid_t cpid;
	
	//int fd,temp,i,j,n=4;
	cpid=fork();
	if(cpid==0)
{
	printf("child");
	child();
	
}

    
	
	else
	{
	wait(&status);
	int i,n=4;
	for (i = 0; i < n; ++i)

        printf("%d\n", a[i]);
	parent();
}

}
void child()
{
	int i,j,n=4,temp;
    for (i = 0; i < n; ++i)

    {

        for (j = i + 1; j < n; ++j)

        {

            if (a[i] > a[j])

            {

                temp =  a[i];

                a[i] = a[j];

                a[j] = temp;

            }

        }
   }

}
void parent()
{
	
	int i,n=4;
	    for (i = 0; i < n; ++i)

        printf("%d\n", a[i]);
}
