#include<sys/wait.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int g = 20;

int main(int argc , char *argv[])
{
	pid_t cpid;
	int status;
	int l = 30;
	
	printf("VALUE OF l : %d\n",l);
	printf("VALUE OF g : %d\n",g);
	printf("\n");
	
	cpid = fork();

	if(cpid==-1)
	{
		printf("Error");
		exit(1);
	}

	else if(cpid==0)
	{
		printf("Child\n");
		l=l+30;
		printf("l inside child after l=l+30 : %d\n",l);
		g = 40;
		printf("g inside child after g=40: %d\n",g);
		printf("\n");
	}
 
 	else
 	{
 		wait(&status);
 		printf("Parent\n");
 		l=l*9;
		printf("l inside parent after l=l*9 : %d\n",l);
		g = g+50;
		printf("g inside parent after g=g+50: %d\n",g);
		printf("\n");
 	}

}
