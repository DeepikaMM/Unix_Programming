#include<sys/wait.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
pid_t cpid,w;
	int status;
	int fd;
	char buf[10];
void parent();
void child();
int main(int argc , char *argv[])
{
	
	
	fd=open("t.txt",O_RDWR | O_CREAT,0664);

	cpid=fork();

	if(cpid==-1)
	{
		printf("Error");
		exit(1);
	}
	if(cpid==0)
	child();
	else
	parent();
	
}
void parent()
{
	//wait(&status);
	write(fd,"parent",6);
	lseek(fd,0,0);
	read(fd,buf,6);
	printf("%s",buf);
}
void child()
{
	write(fd,"child",5);
	lseek(fd,0,0);
	read(fd,buf,6);
	printf("%s",buf);
	//close(fd);
}
