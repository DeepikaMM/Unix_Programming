#include<sys/wait.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main(int argc , char *argv[])
{
	pid_t cpid,w;
	int status;
	int fd;
	char buf[10];
	
	fd=open("h.txt",O_RDWR | O_CREAT,0664);

	cpid=fork();

	if(cpid==-1)
	{
		printf("Error");
		exit(1);
	}

	else if(cpid==0)
	{
		printf("Child\n");
		write(fd,"Hello\n",6);
		printf("- - - - - - -\n");
	}
 
 	else
 	{
 		wait(&status);
 		printf("Parent\n");
 		lseek(fd,0,0);
 		read(fd,buf,6);
 		printf("%s",buf);
 	}

}
