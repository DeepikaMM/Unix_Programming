#include<sys/wait.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main(int argc , char *argv[])
{
	pid_t cpid,w;
	int status;
	/*int fd;
	char buf[10];
	
	fd=open("h.txt",O_RDWR | O_CREAT,0664);*/

	cpid=fork();

	if(cpid==-1)
	{
		printf("Error");
		exit(1);
	}

	else if(cpid==0)
	{
		printf("Process ID of Child : %d\n",getpid());
		printf("UID of Child : %d\n",getuid());
		printf("Effective UID of Child : %d\n",geteuid());
		printf("GID of Child : %d\n",getgid());
		printf("Effective GID of Child : %d\n",getegid());
		printf("_-_-_-_-_-_-_-_-_\n");
	}
 
 	else
 	{
 		wait(&status);
 		printf("Parent\n");
 		printf("Process ID of Parent : %d\n",getppid());
		printf("UID of Parent : %d\n",getuid());
		printf("Effective UID of Parent : %d\n",geteuid());
		printf("GID of Parent : %d\n",getgid());
		printf("Effective GID of Parent : %d\n",getegid());

 	}

}
