//To write a c program to list inode number and filename for every file in a current directory 
//and directory contents passed as command line argument.


#include<stdio.h>
#include<dirent.h>
#include<sys/stat.h>
#include<stdlib.h>

int main(int argc,char* argv[])
{
	/*
	if(argc<2)
	{
		perror("No input arguments");//when only ./a.out :Success
		exit(1);
	}
	*/
	int fd;
	struct stat buf;
	DIR *dr;
	struct dirent *d;
	char buf1[255];
	if(argc<2)
	{
		dr=opendir(".");
	}
	else
		dr=opendir(argv[1]);
	
	while((d=readdir(dr))!=NULL)
	{
		if(strcmp(".",d->d_name)!=0&&strcmp("..",d->d_name)!=0)
		{
			sprintf(buf1,"%s/%s",argv[1],d->d_name);
			printf("name:%s, ",d->d_name);
			stat(buf1,&buf);
			printf("inode:%d\n",buf.st_ino);
		}
	}
}
