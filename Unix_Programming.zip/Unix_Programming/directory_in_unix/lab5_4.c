#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>

int main(int argc , char *argv[])
{
	//int l;
	int r;
	struct stat buf1;
	char *buf;
	/*l=symlink(argv[1],argv[2]);
	{
		perror("error");
		exit(1);
	}*/
		
	lstat(argv[1],&buf);
	buf=malloc(buf1.st_size);
	r = readlink(argv[1],buf,buf1.st_size);
	if(r<0)
	{
		perror("readlink");
		exit(1);
	}
	
	printf("%s-->%s\n",argv[1],buf);
}
