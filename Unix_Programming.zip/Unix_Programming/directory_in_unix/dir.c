#include<stdio.h>
#include<fcntl.h>
#include<dirent.h>
#include<unistd.h>
#include<string.h>
void main()
{
DIR *d;
struct dirent *dir;
struct stat buf;
d=opendir(".");
while((dir=readdir(d))!=NULL)
{
if((strcmp(".",(dir->d_name))!=0)&&(strcmp("..",(dir->d_name))!=0))
{
printf("%s\t",dir->d_name);
stat(dir->d_name,&buf);
printf("%d\n",buf.st_ino);
}
}
}
