#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<dirent.h>
int main(int argc , char * argv[])
{
DIR *d;
struct dirent *dir;
struct stat buf;
if(stat(argv[1],&buf)<0)
{
perror("error");
exit(1);}
d=opendir(".");

while((dir=readdir(d))!=NULL)
{
if((strcmp(".",(dir->d_name))!=0)&&(strcmp("..",(dir->d_name))!=0))
printf("%s\t",dir->d_name);
stat(dir->d_name,&buf);
printf("%d\n",buf.st_ino);
}
}
