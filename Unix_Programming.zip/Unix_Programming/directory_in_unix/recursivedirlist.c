#include <dirent.h>
#include <stdio.h>
#include <string.h>

#include<sys/stat.h>
#include<stdlib.h>
void listDir(char * path)
{
DIR* dir;
struct dirent *ent;
	int fd;
	struct stat buf;
	DIR *dr;
	char buf1[255];
  if((dir=opendir(path)) != NULL)
   {
    while (( ent = readdir(dir)) != NULL)
    {
      if(ent->d_type == DT_DIR && strcmp(ent->d_name, ".") != 0  && strcmp(ent->d_name, "..") != 0)
      {
			sprintf(buf1,"%s/%s",path,ent->d_name);
			printf("name:%s, ",ent->d_name);
			stat(buf1,&buf);
			printf("inode:%d\n",buf.st_ino);
        printf("%s\n", ent->d_name);
        listDir(ent->d_name);
      }
    }
    closedir(dir);
   }
}

void main(){
  listDir(".");
}

