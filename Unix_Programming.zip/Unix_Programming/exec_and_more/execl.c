#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{
char *arr[3]={"ls","-l",(char*)0};
//execl("/bin/ls","ls","-l","-t","-u",(char*)0);
execv("/bin/ls",arr);
printf("hello\n");
}
