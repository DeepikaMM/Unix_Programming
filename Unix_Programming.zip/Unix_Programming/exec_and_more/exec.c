#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{
char *arr[3]={"ls","-l",(char*)0};
//execl("/bin/ls","ls","-l","-t","-u",(char*)0);
//execv("/bin/ls",arr);
//execlp("ls","-l","-t","-u",(char*)0);
//execvp("ls",arr);
execl("./hello.py","./hello.py",(char*)0);
printf("hello\n");
}
