#!/usr/bin/python  
#above is interpretor line 
print "hello"
