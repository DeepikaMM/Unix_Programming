#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{
char *x;
x=getenv("LOGNAME");
printf("%s",x);
}
