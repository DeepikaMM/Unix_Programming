#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{
int x;
x=setenv("LOGNAME","drk",1);
printf("%d\n",x);
char *d;
d=getenv("LOGNAME");
printf("%s",d);
}


// THE CHANGE IS AFFECTED ONLLY FOR THAT PROCESS
