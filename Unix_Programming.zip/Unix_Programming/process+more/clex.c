
// program for user id bit
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>	
main()
{
int fd,fd1,fd2;
struct stat buf;
int status;
pid_t pid;
// open a file

// get the fd
fd=open("a.txt",O_CREAT|O_RDWR,0666);
if(fd<0)
{
perror("open");
exit(1);
}


if (fcntl(fd,F_SETFD,FD_CLOEXEC) == -1) // IF CLOSE ON EXEC FLAG IS SET,FD'S ARE CLOSED AFTER EXEC, AND HENCE ARE NOT INHERITED
{
perror("fcntl");
exit(1);
}
pid=fork();
if(pid<0)
{
perror("fork");
exit(1);
}
else if(pid==0)
{
// execute a new program that writes to a file refered by fd
execl("./new","new",(char*)0);
printf("this statement is never printed\n");
}
else
{
waitpid(pid,&status,0);
write(fd,"i am parent\n",strlen("i am parent\n"));
}
}

