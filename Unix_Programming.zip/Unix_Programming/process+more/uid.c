// program for user id bit
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<sys/stat.h>
main()
{
int fd,fd1,fd2;
struct stat buf;
//open a file here
fd=open("a.txt",O_CREAT|O_RDWR,0666);

if(fd<0)
{
perror("open");
exit(1);
}
// set the user id using setuid(uid)

    setuid(1002);


fstat(fd,&buf);
//print the usre id, euid
printf("My UID is: %d. My GID is: %dn", getuid(), getgid());   // cannot change the userid,only superuser can change
// write to the file any message

}
