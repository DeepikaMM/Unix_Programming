#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{
//fd=open("a.txt",O_CREAT|O_RDWR,0666);
write(3,"helloworld",10);
}
