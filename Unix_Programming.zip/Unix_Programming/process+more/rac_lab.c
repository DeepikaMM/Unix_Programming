#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>

static void charatatime(char *);
int main(void)
{
pid_t pid;
if ((pid = fork()) < 0) {
perror("fork error");
} 
else if (pid == 0) 
{
charatatime("output from child\n");
} 
else 
{
charatatime("output from parent\n");
}
exit(0);
}
static void charatatime(char *str)
{
    while(*str != '\0')
    {
        char buff[255];
        setvbuf(stdout, buff, _IONBF, 0); 
        putchar(*str++);
    }
    printf("\n");
}
